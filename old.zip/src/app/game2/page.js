"use client";
import React, { useState } from 'react';
import { CheckCircle, Circle, AlertCircle, Play, Database } from 'lucide-react';

const ExorcismGame = () => {
  const questions = [
    {
      id: 1,
      question: "Ritual shuru hone se pehle sabse zyada chadhaya gaya phal kaun tha?",
      expectedOutput: [{ item_name: "Coconut" }],
      hint: "Use WHERE clause to filter by item_type 'fruit' and offered_in_ritual TRUE, then ORDER BY used_count DESC LIMIT 1",
      tables: ["exorcism_items"]
    },
    {
      id: 2,
      question: "Sabse frequently use hone wali mala kaunsi thi?",
      expectedOutput: [{ item_name: "Rosary" }],
      hint: "Filter by item_type 'rosary' and ORDER BY used_count DESC LIMIT 1",
      tables: ["exorcism_items"]
    },
    {
      id: 3,
      question: "Kaunsa patta har ritual mein sabse pehle jalta tha?",
      expectedOutput: [{ item_name: "Neem Leaf" }],
      hint: "Filter by item_type 'leaf' and ORDER BY burn_count DESC LIMIT 1",
      tables: ["exorcism_items"]
    },
    {
      id: 4,
      question: "Ritual ke dauran kisi ne chadhaya hua paani kis jagah use kiya?",
      expectedOutput: [{ item_name: "Holy Water" }],
      hint: "Filter by item_type 'holy_water' and location_used = 'altar'",
      tables: ["exorcism_items"]
    },
    {
      id: 5,
      question: "Ek non-ritual item jo distractor tha, par teams confuse ho sakti thi?",
      expectedOutput: [{ item_name: "Silver Thread" }],
      hint: "Search for the item_name 'Silver Thread'",
      tables: ["exorcism_items"]
    }
  ];

  const [queries, setQueries] = useState({});
  const [results, setResults] = useState({});
  const [validationStatus, setValidationStatus] = useState({});
  const [errors, setErrors] = useState({});
  const [loading, setLoading] = useState({});
  const [score, setScore] = useState(0);
  const [showHints, setShowHints] = useState({});

  // Function to call your executeQuery function
  const executeQueryHandler = async (questionId, query) => {
    if (!query.trim()) return;

    setLoading(prev => ({ ...prev, [questionId]: true }));
    setErrors(prev => ({ ...prev, [questionId]: null }));
    setResults(prev => ({ ...prev, [questionId]: null }));

    try {
      // Call your executeQuery function
      const response = await fetch('/api/execute-query', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ query }),
      });

      const result = await response.json();

      if (result.success) {
        setResults(prev => ({ ...prev, [questionId]: result.data }));
        
        // Validate the result
        const isCorrect = validateQueryResult(questionId, result.data);
        setValidationStatus(prev => ({ ...prev, [questionId]: isCorrect ? 'correct' : 'incorrect' }));
        
        // Update score
        updateScore();
      } else {
        setErrors(prev => ({ 
          ...prev, 
          [questionId]: result.error
        }));
        setValidationStatus(prev => ({ ...prev, [questionId]: 'error' }));
      }
      
    } catch (error) {
      setErrors(prev => ({ 
        ...prev, 
        [questionId]: `Network Error: ${error.message}` 
      }));
      setValidationStatus(prev => ({ ...prev, [questionId]: 'error' }));
    } finally {
      setLoading(prev => ({ ...prev, [questionId]: false }));
    }
  };

  // Function to validate query result against expected output
  const validateQueryResult = (questionId, result) => {
    const question = questions.find(q => q.id === questionId);
    if (!question || !result || result.length === 0) return false;

    const expected = question.expectedOutput[0];
    const actual = result[0];

    // Compare the key fields that matter
    if (expected.item_name && actual.item_name) {
      return expected.item_name.toLowerCase() === actual.item_name.toLowerCase();
    }

    // Fallback to JSON comparison
    return JSON.stringify(actual) === JSON.stringify(expected);
  };

  // Update score based on correct answers
  const updateScore = () => {
    setTimeout(() => {
      const correctAnswers = Object.values(validationStatus).filter(status => status === 'correct').length;
      setScore(correctAnswers);
    }, 100);
  };

  // Handle query input change
  const handleQueryChange = (questionId, value) => {
    setQueries(prev => ({ ...prev, [questionId]: value }));
  };

  // Toggle hint visibility
  const toggleHint = (questionId) => {
    setShowHints(prev => ({ ...prev, [questionId]: !prev[questionId] }));
  };

  // Get status icon
  const getStatusIcon = (questionId) => {
    const status = validationStatus[questionId];
    if (loading[questionId]) {
      return <div className="w-5 h-5 border-2 border-blue-500 border-t-transparent rounded-full animate-spin" />;
    }
    
    switch (status) {
      case 'correct':
        return <CheckCircle className="w-5 h-5 text-green-500" />;
      case 'incorrect':
        return <Circle className="w-5 h-5 text-red-500" />;
      case 'error':
        return <AlertCircle className="w-5 h-5 text-red-500" />;
      default:
        return <Circle className="w-5 h-5 text-gray-400" />;
    }
  };

  // Check if game is completed
  const isGameCompleted = Object.values(validationStatus).filter(status => status === 'correct').length === questions.length;

  // Reset game
  const resetGame = () => {
    setQueries({});
    setResults({});
    setValidationStatus({});
    setErrors({});
    setLoading({});
    setScore(0);
    setShowHints({});
  };

  return (
    <div className="max-w-6xl mx-auto p-6 bg-gradient-to-br from-purple-900 via-blue-900 to-indigo-900 min-h-screen">
      <div className="bg-black/30 backdrop-blur-sm rounded-lg p-6 border border-purple-500/30">
        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold text-white mb-2 flex items-center justify-center gap-2">
            <Database className="w-8 h-8" />
            🔮 SQL Exorcism Mystery Game
          </h1>
          <div className="flex justify-center items-center gap-4 text-white">
            <div className="bg-purple-600/30 px-4 py-2 rounded-lg">
              Score: {score}/5
            </div>
            {isGameCompleted && (
              <div className="bg-green-600/30 px-4 py-2 rounded-lg animate-pulse">
                🎉 All Mysteries Solved!
              </div>
            )}
          </div>
        </div>

        {/* Questions Grid */}
        <div className="grid gap-8">
          {questions.map((question) => (
            <div 
              key={question.id} 
              className={`bg-black/20 rounded-lg p-6 border transition-all duration-300 ${
                validationStatus[question.id] === 'correct' 
                  ? 'border-green-500/50 bg-green-900/10' 
                  : validationStatus[question.id] === 'incorrect' || validationStatus[question.id] === 'error'
                  ? 'border-red-500/50 bg-red-900/10'
                  : 'border-purple-500/30'
              }`}
            >
              {/* Question Header */}
              <div className="flex items-start justify-between mb-4">
                <div className="flex-1">
                  <h3 className="text-white font-semibold text-lg mb-2">
                    Q{question.id}: {question.question}
                  </h3>
                  <div className="text-sm text-gray-400">
                    Tables: {question.tables.join(', ')}
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  {getStatusIcon(question.id)}
                  <button
                    onClick={() => toggleHint(question.id)}
                    className="text-yellow-400 hover:text-yellow-300 transition-colors"
                  >
                    <AlertCircle className="w-5 h-5" />
                  </button>
                </div>
              </div>

              {/* SQL Query Input */}
              <div className="mb-4">
                <label className="block text-white text-sm font-medium mb-2">
                  SQL Query:
                </label>
                <div className="relative">
                  <textarea
                    value={queries[question.id] || ''}
                    onChange={(e) => handleQueryChange(question.id, e.target.value)}
                    placeholder="SELECT item_name FROM exorcism_items WHERE..."
                    className={`w-full px-4 py-3 rounded-lg bg-black/30 border text-white placeholder-gray-400 focus:outline-none focus:ring-2 transition-all font-mono text-sm min-h-[100px] resize-y ${
                      validationStatus[question.id] === 'correct'
                        ? 'border-green-500 focus:ring-green-500/30'
                        : validationStatus[question.id] === 'incorrect' || validationStatus[question.id] === 'error'
                        ? 'border-red-500 focus:ring-red-500/30'
                        : 'border-purple-500/50 focus:ring-purple-500/30'
                    }`}
                    rows={4}
                  />
                  <button
                    onClick={() => executeQueryHandler(question.id, queries[question.id])}
                    disabled={!queries[question.id]?.trim() || loading[question.id]}
                    className="absolute bottom-3 right-3 px-3 py-1 bg-blue-600 hover:bg-blue-700 disabled:bg-gray-600 disabled:cursor-not-allowed text-white rounded text-sm flex items-center gap-1 transition-colors"
                  >
                    <Play className="w-3 h-3" />
                    {loading[question.id] ? 'Running...' : 'Run Query'}
                  </button>
                </div>
              </div>

              {/* Query Results */}
              {results[question.id] && results[question.id].length > 0 && (
                <div className="mb-4 bg-gray-900/50 rounded-lg p-4 border border-gray-600/30">
                  <h4 className="text-white text-sm font-medium mb-2">
                    Query Result ({results[question.id].length} row{results[question.id].length > 1 ? 's' : ''}):
                  </h4>
                  <div className="overflow-x-auto">
                    <table className="w-full text-xs text-gray-300">
                      <thead>
                        <tr className="border-b border-gray-600">
                          {results[question.id].length > 0 && Object.keys(results[question.id][0]).map(col => (
                            <th key={col} className="text-left p-2 font-medium text-gray-200">{col}</th>
                          ))}
                        </tr>
                      </thead>
                      <tbody>
                        {results[question.id].slice(0, 5).map((row, idx) => (
                          <tr key={idx} className="border-b border-gray-700/50">
                            {Object.values(row).map((val, colIdx) => (
                              <td key={colIdx} className="p-2">{String(val)}</td>
                            ))}
                          </tr>
                        ))}
                      </tbody>
                    </table>
                    {results[question.id].length > 5 && (
                      <p className="text-gray-400 text-xs mt-2">
                        ... and {results[question.id].length - 5} more rows
                      </p>
                    )}
                  </div>
                </div>
              )}

              {/* Empty Results */}
              {results[question.id] && results[question.id].length === 0 && (
                <div className="mb-4 bg-gray-900/50 rounded-lg p-4 border border-gray-600/30">
                  <p className="text-gray-400 text-sm">No results returned by query.</p>
                </div>
              )}

              {/* Error Display */}
              {errors[question.id] && (
                <div className="mb-4 bg-red-900/20 border border-red-500/30 rounded-lg p-3">
                  <p className="text-red-300 text-sm">
                    ❌ <strong>Error:</strong> {errors[question.id]}
                  </p>
                </div>
              )}

              {/* Hint */}
              {showHints[question.id] && (
                <div className="bg-yellow-900/20 border border-yellow-500/30 rounded-lg p-4 mb-4">
                  <p className="text-yellow-200 text-sm">
                    💡 <strong>Hint:</strong> {question.hint}
                  </p>
                </div>
              )}

              {/* Success Message */}
              {validationStatus[question.id] === 'correct' && (
                <div className="bg-green-900/20 border border-green-500/30 rounded-lg p-3">
                  <p className="text-green-300 text-sm">
                    ✅ Perfect! Your query returned the correct result: <strong>{question.expectedOutput[0].item_name}</strong>
                  </p>
                </div>
              )}
              
              {validationStatus[question.id] === 'incorrect' && (
                <div className="bg-red-900/20 border border-red-500/30 rounded-lg p-3">
                  <p className="text-red-300 text-sm">
                    ❌ The query result doesn't match the expected answer. Expected: <strong>{question.expectedOutput[0].item_name}</strong>
                  </p>
                  <p className="text-red-200 text-xs mt-1">
                    Try refining your query or check the hint for guidance.
                  </p>
                </div>
              )}
            </div>
          ))}
        </div>

        {/* Game Completion */}
        {isGameCompleted && (
          <div className="mt-8 text-center">
            <div className="bg-green-600/20 border border-green-500/50 rounded-lg p-6">
              <h2 className="text-2xl font-bold text-green-300 mb-2">
                🎊 SQL Master Detective! 🎊
              </h2>
              <p className="text-green-200 mb-4">
                You've successfully solved all the exorcism mysteries using SQL!
              </p>
              <button
                onClick={resetGame}
                className="px-6 py-3 bg-purple-600 hover:bg-purple-700 text-white rounded-lg transition-colors"
              >
                Start New Game
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default ExorcismGame;